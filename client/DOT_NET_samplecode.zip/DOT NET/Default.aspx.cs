﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Text;
using System.IO;
using System.Data;
using System.Xml;

public partial class _Default : System.Web.UI.Page
{
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            clnTo.SelectedDate = DateTime.Now;
            clnFrom.SelectedDate = DateTime.Now;
            FillGrid();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private void FillGrid()
    {
        //Set the Virtual Path for the XML file
        string lcUrl = string.Empty;
        string url = HttpContext.Current.Request.Url.AbsoluteUri;

        if (Request.QueryString["state_code"] == null && Request.QueryString["state_name"] == null && Request.QueryString["regdateTo"] == null && Request.QueryString["regdateFrom"] == null && Request.QueryString["reg_source"] == null && Request.QueryString["searchname"] == null && Request.QueryString["per_page_rec"] == null)
        {
            if (Request.QueryString["page"] == null)
            {
                lcUrl = Server.HtmlDecode(System.Configuration.ConfigurationManager.AppSettings["GetVntClient"].ToString().Replace("amp;", "&amp;")) + "&per_page_rec=" + System.Configuration.ConfigurationManager.AppSettings["PerPageRecord"].ToString() + "&page=1";
                txtPageNumber.Text = "1";
            }
            else
            {
                lcUrl = Server.HtmlDecode(System.Configuration.ConfigurationManager.AppSettings["GetVntClient"].ToString().Replace("amp;", "&amp;")) + "&per_page_rec=" + System.Configuration.ConfigurationManager.AppSettings["PerPageRecord"].ToString() + "&page=" + Request.QueryString["page"];
                txtPageNumber.Text = Request.QueryString["page"];
            }

        }
        else
        {
            //lcUrl = Server.HtmlDecode(System.Configuration.ConfigurationManager.AppSettings["GetVntClient"].ToString().Replace("amp;", "&amp;")) + "&page=" + Request.QueryString["page"] + "&per_page_rec=" + System.Configuration.ConfigurationManager.AppSettings["PerPageRecord"].ToString();
            lcUrl = Server.HtmlDecode(System.Configuration.ConfigurationManager.AppSettings["GetVntClient"].ToString().Replace("amp;", "&amp;")) + "&state_code=" + Request.QueryString["state_code"].ToString() + "&state_name=" + Request.QueryString["state_name"].ToString() + "&regdateTo=" + Request.QueryString["regdateTo"].ToString() + "&regdateFrom=" + Request.QueryString["regdateFrom"].ToString() + "&reg_source=" + Request.QueryString["reg_source"].ToString() + "&searchname=" + Request.QueryString["searchname"].ToString() + "&page=" + Request.QueryString["page"].ToString() + "&per_page_rec=" + Request.QueryString["per_page_rec"].ToString();

            ListItem ddlState1 = ddlState.Items.FindByValue(Request.QueryString["state_code"]);
            if (ddlState1 != null)
                ddlState1.Selected = true;

            ListItem ddlRegSource1 = ddlRegSource.Items.FindByValue(Request.QueryString["reg_source"]);
            if (ddlRegSource1 != null)
                ddlRegSource1.Selected = true;

            txtName.Text = Request.QueryString["searchname"];
            clnFrom.TodaysDate = Convert.ToDateTime(Request.QueryString["regdateFrom"]);
            clnTo.TodaysDate = Convert.ToDateTime(Request.QueryString["regdateTo"]);
        }

        //HttpWebRequest loHttp = (HttpWebRequest)WebRequest.Create(lcUrl);
        //HttpWebResponse loWebResponse = (HttpWebResponse)loHttp.GetResponse();
        //Encoding enc = Encoding.GetEncoding(1252);
        //StreamReader loResponseStream = new StreamReader(loWebResponse.GetResponseStream(), enc);
        //string lcHtml = loResponseStream.ReadToEnd();
        //loWebResponse.Close();
        //loResponseStream.Close();

        Uri uri = new Uri(lcUrl);
        string data = "&HTTP_REFFERER=" + url;
        HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
        request.Method = WebRequestMethods.Http.Post;
        request.ContentLength = data.Length;
        request.ContentType = "application/x-www-form-urlencoded";
        StreamWriter writer = new StreamWriter(request.GetRequestStream());
        writer.Write(data);
        writer.Close();
        Encoding enc = Encoding.GetEncoding(1252);
        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        StreamReader loResponseStream = new StreamReader(response.GetResponseStream(), enc);
        string lcHtml = loResponseStream.ReadToEnd();
        response.Close();
        loResponseStream.Close();

        // Save XML file 
        File.WriteAllText(Request.PhysicalApplicationPath + "GetUser1.xml", lcHtml);

        DataSet ds = new DataSet();
        ds.ReadXml(Request.PhysicalApplicationPath + "GetUser1.xml");

        if (!ds.Tables[0].Columns.Contains("Error"))
        {
            string strPagging = string.Empty;
            string strTotalPage = string.Empty;

            lblCurrentPage.Text = "Current Page: " + Convert.ToString(ds.Tables[0].Rows[0]["page"]);
            lblPerPageRecords.Text = "Per Page Records: " + Convert.ToString(ds.Tables[0].Rows[0]["per_page_rec"]);
            lblTotalRecords.Text = "Total Records: " + Convert.ToString(ds.Tables[0].Rows[0]["nototaldata"]);
            strTotalPage = Convert.ToString(Convert.ToDouble(ds.Tables[0].Rows[0]["nototaldata"]) / Convert.ToDouble(ds.Tables[0].Rows[0]["per_page_rec"]) + 1);
            strTotalPage = strTotalPage.Substring(0, strTotalPage.IndexOf("."));

            lblTotalPages.Text = "Total Page: " + strTotalPage;
            lblPage.Text = "Page " + Convert.ToString(ds.Tables[0].Rows[0]["page"]) + " of " + strTotalPage;
            for (int i = 1; i <= Convert.ToInt32(strTotalPage); i++)
            {
                strPagging += "<a href ='Default.aspx?page=" + i + "'>" + i + "</a> | ";
            }


            lblPaging.Text = Server.HtmlDecode(strPagging.Substring(0, strPagging.Length - 2));

            DataTable dttest = ds.Tables[2];
            ds.Tables[2].Rows.RemoveAt(0);
            int cunt = ds.Tables[2].Rows.Count;

            DataTable dtAll = null;
            dtAll = ds.Tables[8].Copy();
            dtAll.Merge(ds.Tables[2]);
            GridView1.DataSource = dtAll;
            GridView1.DataBind();
        }
        else
        {
            if (ds.Tables[0].Rows[0]["Error"] == "")
            {
                lblError.Visible = false;
            }
            else
            {
                lblError.Visible = true;
                lblError.Text = Convert.ToString(ds.Tables[0].Rows[0]["Error"]);
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string strstate_code = string.Empty;
        string strstate_name = string.Empty;

        string regdateTo = string.Empty;
        string regdateFrom = string.Empty;
        string strreg_source = string.Empty;
        string strsearchname = string.Empty;
        string strpage = string.Empty;
        string strper_page_rec = string.Empty;

        strstate_code = ddlState.SelectedItem.Value;
        strstate_name = ddlState.SelectedItem.Text;
        regdateTo = string.Format("{0:yyyy-MM-dd}", clnTo.SelectedDate);
        regdateFrom = string.Format("{0:yyyy-MM-dd}", clnFrom.SelectedDate);
        strreg_source = ddlRegSource.SelectedItem.Value;
        strsearchname = txtName.Text;

        if (Request.QueryString["page"] == null)
            strpage = Convert.ToString(1);
        else
            strpage = Convert.ToString(Request.QueryString["page"]);

        //strpage = txtPageNumber.Text;
        strper_page_rec = System.Configuration.ConfigurationManager.AppSettings["PerPageRecord"].ToString();

        string redirectURL = "Default.aspx?state_code=" + strstate_code + "&state_name=" + strstate_name + "&regdateTo=" + regdateTo +
        "&regdateFrom=" + regdateFrom + "&reg_source=" + strreg_source + "&searchname=" + strsearchname + "&page=" + strpage + "&per_page_rec=" + strper_page_rec + "";

        Response.Redirect(redirectURL);
    }
    protected void lnkNext_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx?page=" + txtPageNumber.Text);
    }
}
